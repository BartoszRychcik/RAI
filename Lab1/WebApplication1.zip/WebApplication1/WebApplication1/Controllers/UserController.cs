﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace WebApplication1.Controllers
{
    
    public class UserController : Controller
    {
        private static List<Models.User> database;
        

        public IActionResult Add()
        {
            string user = HttpContext.Session.GetString("user");
            if (user == "admin")
            {
                ViewData["Message"] = "Wpisz dane dla nowego użytkownika.";
                return View();
            }
            return RedirectToAction("Error", "User", new {code=403 });
        }

        [HttpPost]
        public IActionResult Add(IFormCollection form)
        {
            string user = HttpContext.Session.GetString("user");
            if (user == "admin")
            {
                database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            string login = form["login"];
            if (login.Length <= 3 || login.Length >= 32) ModelState.AddModelError("dlugosc", "Login musi mieć od 3 do 32 znaków.");
            ViewData["Message"] = "Wpisz dane dla nowego użytkownika.";
            foreach(var x in database)
            {
                if(x.login==login)
                    ModelState.AddModelError("duplikat", "Użytkownik o podanej nazwie już istnieje.");
            }
            if (!ModelState.IsValid) return View();

            Models.User user2 = new Models.User(login,DateTime.Now, new List<string>());
            
            database.Add(user2);
            HttpContext.Session.SetString("database",JsonConvert.SerializeObject(database));

            ViewData["Message"] = "Pomyślnie dodano użytkownika "+login.ToString()+".";
            ViewBag.database = database;
            return View("List");
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult Init()
        {
            string user = HttpContext.Session.GetString("user");
            if (user == "admin")
            {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            Random rnd = new Random();
        
            for (int i = 0; i < 5; i++)
            {
                Models.User user2 = new Models.User("user" + i.ToString(), DateTime.Now, new List<string>());
               
                int x = rnd.Next() % 2 + 1;
                for (int j = 0; j < x; j++)
                {
                    int k = i;
                    while(k==i)
                        k = rnd.Next() % 5;
                    user2.AddFriend("user"+k.ToString());
                }
                database.Add(user2);
            }

            HttpContext.Session.SetString("database", JsonConvert.SerializeObject(database));
            ViewData["Message"] = "Zainicjalizowano baze danych. ";
            ViewBag.database = database;
            return View("List");
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult Del(string login)
        {
            string user = HttpContext.Session.GetString("user");
            if (user == "admin")
            {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            int i = 0;
            foreach(var x in database)
            {
                if (x.login == login) break;
                i++;
            }
            database.RemoveAt(i);
            foreach (var x in database)
            {
                x.friends = x.friends.Where(val => val != login).ToList();
            }

            HttpContext.Session.SetString("database", JsonConvert.SerializeObject(database));
            return RedirectToAction("List", "User");
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult List()
        {
            string user = HttpContext.Session.GetString("user");
            if (user == "admin")
            {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            ViewData["Message"] = "Lista użytkowników.";
            ViewBag.database = database;
            return View();
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        
        public IActionResult Login(string login)
        {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            foreach (var x in database)
            {
                if (x.login == login)
                {
                    HttpContext.Session.SetString("user", login);
                    if (login == "admin")
                        return RedirectToAction("List", "User");
                    else
                        return RedirectToAction("List", "Friends");
                }
            }
            return RedirectToAction("Error", "User", new { code = -1 });  
        }

        public IActionResult Logout()
        {
            string user = HttpContext.Session.GetString("user");
            if (user != "")
            {
            HttpContext.Session.SetString("user","");
            return RedirectToAction("Index", "Home");
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult Error(int code)
        {
            if (code == -1)
                ViewData["Message"] = "Twój login jest nieprawidłowy.";
            else
                ViewData["Message"] = "Wystąpił błąd " + code.ToString() + ".";
            return View();
        }
    }
}