﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace WebApplication1.Models
{
    public class User
    {
        [Display(Name = "Nazwa użytkownika")]
        [StringLength(9, MinimumLength = 3, ErrorMessage ="len = 3..9")]
        public string login { get; set; }

        [Display(Name = "Hasło użytkownika")]
        public string password { get; set; }

        [Display(Name = "Data rejestracji")]
        public DateTime time { get; set; }
        [Display(Name = "Lista przyjaciół")]
        public List<string> friends { get; set; }
        [Display(Name = "Avatar")]
        public string avatar { get; set; }

        public User(string login, string password,DateTime time, List<string> friends)
        {
            this.login = login;
            this.time = time;
            this.password = password;
            this.friends = friends;
            this.avatar = "~/images/default.png";
        }

        public bool AddFriend(string login)
        {
            foreach (string x in this.friends)
            {
                if (x == login) return false;
            }
            this.friends.Add(login);
            return true;
        }

        public bool DeleteFriend(string login)
        {
            foreach (string x in this.friends)
            {
                if (x == login)
                {
                    this.friends.Remove(login);
                    return true;
                }
            }
            return false;
        }

        public int IndexFriend(string login)
        {
            int i = 0;
            foreach(string x in this.friends)
            {
                if (x == login) return i;
                i++;
            }
            return -1;
        }
    }
}
