﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace WebApplication1.Controllers
{

    public class UserController : Controller
    {
        private static List<Models.User> database;


        public IActionResult Add()
        {
            string user = HttpContext.Session.GetString("user");
            if (user == "admin")
            {
                ViewData["Message"] = "Wpisz dane dla nowego użytkownika.";
                return View();
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        [HttpPost]
        public IActionResult Add(IFormCollection form)
        {
            string user = HttpContext.Session.GetString("user");
            if (user == "admin")
            {
                database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
                string login = form["login"];
                string password = form["password"];
                if (login.Length <= 3 || login.Length >= 32) ModelState.AddModelError("dlugosc", "Login musi mieć od 3 do 32 znaków.");
                ViewData["Message"] = "Wpisz dane dla nowego użytkownika.";
                foreach (var x in database)
                {
                    if (x.login == login)
                        ModelState.AddModelError("duplikat", "Użytkownik o podanej nazwie już istnieje.");
                }
                if (!ModelState.IsValid) return View();

                Models.User user2 = new Models.User(login, password, DateTime.Now, new List<string>());

                database.Add(user2);
                HttpContext.Session.SetString("database", JsonConvert.SerializeObject(database));

                ViewData["Message"] = "Pomyślnie dodano użytkownika " + login.ToString() + ".";
                ViewBag.database = database;
                return View("List");
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult Init()
        {
            string user = HttpContext.Session.GetString("user");
            if (user == "admin")
            {
                database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
                Random rnd = new Random();

                for (int i = 0; i < 5; i++)
                {
                    Models.User user2 = new Models.User("user" + i.ToString(), "12345", DateTime.Now, new List<string>());

                    int x = rnd.Next() % 2 + 1;
                    for (int j = 0; j < x; j++)
                    {
                        int k = i;
                        while (k == i)
                            k = rnd.Next() % 5;
                        user2.AddFriend("user" + k.ToString());
                    }
                    database.Add(user2);
                }

                HttpContext.Session.SetString("database", JsonConvert.SerializeObject(database));
                ViewData["Message"] = "Zainicjalizowano baze danych. ";
                ViewBag.database = database;
                return View("List");
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult Del(string login)
        {
            string user = HttpContext.Session.GetString("user");
            if (user == "admin")
            {
                database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
                int i = 0;
                foreach (var x in database)
                {
                    if (x.login == login) break;
                    i++;
                }
                database.RemoveAt(i);
                foreach (var x in database)
                {
                    x.friends = x.friends.Where(val => val != login).ToList();
                }

                HttpContext.Session.SetString("database", JsonConvert.SerializeObject(database));
                return RedirectToAction("List", "User");
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult List()
        {
            string user = HttpContext.Session.GetString("user");
            if (user == "admin")
            {
                database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
                ViewData["Message"] = "Lista użytkowników.";
                ViewBag.database = database;
                return View();
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }


        public IActionResult Login(string login)
        {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            foreach (var x in database)
            {
                if (x.login == login)
                {
                    HttpContext.Session.SetString("user", login);
                    if (login == "admin")
                        return RedirectToAction("List", "User");
                    else
                        return RedirectToAction("List", "Friends");
                }
            }
            return RedirectToAction("Error", "User", new { code = -1 });
        }

        public IActionResult Login2()
        {
            ViewData["Message"] = "Wpisz dane do logowania.";
            return View();
        }

        [HttpPost]
        public IActionResult Login2(IFormCollection form)
        {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            string login = form["login"];
            string password = form["password"];

            foreach (var x in database)
            {
                if (x.login == login && x.password == password)
                {
                    HttpContext.Session.SetString("user", login);
                    if (login == "admin")
                        return RedirectToAction("List", "User");
                    else
                        return RedirectToAction("List", "Friends");
                }
            }
            return RedirectToAction("Error", "User", new { code = -1 });
        }

        public IActionResult Logout()
        {
            string user = HttpContext.Session.GetString("user");
            if (user != "")
            {
                HttpContext.Session.SetString("user", "");
                return RedirectToAction("Index", "Home");
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult Error(int code)
        {
            if (code == -1)
                ViewData["Message"] = "Twój login lub hasło jest nieprawidłowe.";
            else
                ViewData["Message"] = "Wystąpił błąd " + code.ToString() + ".";
            return View();
        }

        public IActionResult Avatar(string login)
        {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            foreach (var x in database)
            {
                if (x.login == login)
                {
                    ViewBag.avatar = x.avatar;
                }
            }
            return View();
        }


        public IActionResult Edit()
        {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            string user = HttpContext.Session.GetString("user");
            if (user != "")
            {
                foreach (var x in database)
                {
                    if (x.login == user)
                    {
                        ViewBag.avatar = x.avatar;
                        ViewBag.password = x.password;
                    }
                }

                ViewData["Message"] = "Edycja konta.";
                return View();
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        [HttpPost]
        public IActionResult Edit(IFormFile file)
        {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            string user = HttpContext.Session.GetString("user");
            if (user != "")
            {

                if (file == null)
                {
                    ModelState.AddModelError("pusty", "Wybierz plik, który chcesz przesłać.");
                }
                else
                {
                    byte[] data = new byte[1024];
                    var s = Request.Form.Files["file2"].OpenReadStream();
                    s.Read(data, 0, 1024);

                    if (data[0] != 0x89 || data[1] != 0x50 || data[2] != 0x4e || data[3] != 0x47)
                        ModelState.AddModelError("png", "To nie jest plik PNG.");
                    if (!ModelState.IsValid) return View();

                    foreach (var x in database)
                    {
                        if (x.login == user)
                        {
                            //x.password = password;
                        }
                    }

                    HttpContext.Session.SetString("database", JsonConvert.SerializeObject(database));
                    return RedirectToAction("List", "Friends");
                }
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }
    }
}