﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace WebApplication1.Controllers
{
    
    public class FriendsController : Controller
    {
        private static List<Models.User> database;

        public IActionResult Add(string login)
        {
            string user = HttpContext.Session.GetString("user");
            if (user != "")
            {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            foreach(var x in database)
            {
                if (x.login == user)
                {
                        foreach (var k in database)
                        {
                            if (k.login == login)
                            {
                                bool result = x.AddFriend(login);
                                if (result)
                                {
                                    HttpContext.Session.SetString("database", JsonConvert.SerializeObject(database));
                                    return Json(true);
                                }
                                else
                                    return Json(false);
                            }
                        }
                return Json(false);
                }
            }
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult Del(string login)
        {
            string user = HttpContext.Session.GetString("user");
            if (user != "")
            {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));

                foreach (var x in database)
                {
                    foreach (var k in database)
                    {
                        if (k.login == login)
                        {
                            bool result = x.DeleteFriend(login);
                            if (result)
                            {
                                HttpContext.Session.SetString("database", JsonConvert.SerializeObject(database));
                                return Json(true);
                            }
                            else
                                return Json(false);
                        }
                    }
                    return Json(false);
                }
                return Json(false);
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult List()
        {
            string user = HttpContext.Session.GetString("user");
            if (user != "")
            {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            foreach (var x in database)
            {
                if (x.login == user)
                {
                    ViewBag.friends = x.friends;
                    return View();
                }
            }
            return View();
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult Export()
        {
            string user = HttpContext.Session.GetString("user");
            if (user != "")
            {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            
            string[] friends = null;
            foreach (var x in database)
            {
                if (x.login == user)
                    friends = x.friends.ToArray();
            }
            return File(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(friends)), "text/plain", "MyFriends.txt");
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        public IActionResult Import()
        {
            string user = HttpContext.Session.GetString("user");
            if (user != "")
            {
            ViewData["Message"] = "Importuj przyjaciół.";
            return View();
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }

        [HttpPost]
        public IActionResult Import(IFormFile file)
        {
            string user = HttpContext.Session.GetString("user");
            if (user != "")
            {
            database = JsonConvert.DeserializeObject<List<Models.User>>(HttpContext.Session.GetString("database"));
            if (file == null)
            {
                ModelState.AddModelError("pusty", "Wybierz plik, który chcesz przesłać.");
            }
            else
            {
                byte[] data = new byte[1024]; 
                var s = Request.Form.Files["file"].OpenReadStream();
                s.Read(data, 0, 1024);

                List<string> friends = JsonConvert.DeserializeObject<List<string>>(Encoding.ASCII.GetString(data));
                ViewBag.friends = friends;
                foreach (var x in database)
                {
                    if (x.login == user)
                    {
                        x.friends = friends;
                    }
                }
            }
            if (!ModelState.IsValid) return View();
            
            HttpContext.Session.SetString("database", JsonConvert.SerializeObject(database));
            ViewData["Message"] = "Zaimportowano pomyślnie.";
            return View("List");
            }
            return RedirectToAction("Error", "User", new { code = 403 });
        }
    }
}